import java.util.List;

public interface VehicleManager {
    void addVehicle(Vehicle vehicle) throws DuplicateVehicleException;
    List<Vehicle> searchVehicles(String make, String model, String vin);
    List<Vehicle> getAllVehicles();
    void removeVehicle(String vin) throws NoSuchVehicleException;
}
