public class Car extends Vehicle {
    private int numberOfDoors;
    public String bodyType;

    public Car(String make, String model, int yearOfProduction, String color, String vin, String fuelType, int numberOfDoors, String bodyType) {
        super(make, model, yearOfProduction, color, vin, fuelType);
        this.numberOfDoors = numberOfDoors;
        this.bodyType = bodyType;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public String getBodyType() {
        return bodyType;
    }
}
