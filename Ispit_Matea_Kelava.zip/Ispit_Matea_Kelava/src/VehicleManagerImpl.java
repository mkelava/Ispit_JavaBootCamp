import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VehicleManagerImpl implements VehicleManager {

    private Map<String, Vehicle> vehicleMap = new HashMap<>();

    public void addVehicle(Vehicle vehicle) throws DuplicateVehicleException {
        if (vehicleMap.containsKey(vehicle.getVin())) {
            throw new DuplicateVehicleException("Vehicle with VIN " + vehicle.getVin() + " already exists.");
        }
        vehicleMap.put(vehicle.getVin(), vehicle);
    }


    public List<Vehicle> searchVehicles(String make, String model, String vin) {
        List<Vehicle> results = new ArrayList<>();
        for (Vehicle vehicle : vehicleMap.values()) {
            if ((make == null || make.equals(vehicle.getMake())) &&
                    (model == null || model.equals(vehicle.getModel())) &&
                    (vin == null || vin.equals(vehicle.getVin()))) {
                results.add(vehicle);
            }
        }
        return results;
    }

    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicleMap.values());
    }

    public void removeVehicle(String vin) throws NoSuchVehicleException {
        if (!vehicleMap.containsKey(vin)) {
            throw new NoSuchVehicleException("Vehicle with VIN " + vin + " does not exist.");
        }
        vehicleMap.remove(vin);
    }
}
