public abstract class Vehicle {
    private String make;
    private String model;
    private int yearOfProduction;
    private String color;
    private String vin;
    private String fuelType;

    public Vehicle(String make, String model, int yearOfProduction, String color, String vin, String fuelType) {
        this.make = make;
        this.model = model;
        this.yearOfProduction = yearOfProduction;
        this.color = color;
        this.vin = vin;
        this.fuelType = fuelType;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYearOfProduction() {
        return yearOfProduction;
    }

    public String getColor() {
        return color;
    }

    public String getVin() {
        return vin;
    }

    public String getFuelType() {
        return fuelType;
    }
}
